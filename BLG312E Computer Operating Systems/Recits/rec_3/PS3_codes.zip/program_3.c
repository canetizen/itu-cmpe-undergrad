#include <pthread.h> 
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#define SLEEP_DURATION 200000
int myglobal;

void* thread_function(void *arg) {
	int i,j;
	// changing the value of myglobal in thread_function
	for(i=0; i<20; i++) {
		//myglobal++
		j=myglobal;
		j=j+1;
		printf(".");
		// to force writing all user-space buffered data to stdout
		fflush(stdout);
		usleep(SLEEP_DURATION);
		myglobal=j;
	}
	pthread_exit(NULL);
}

int main() {
	pthread_t mythread;
	int i;
	myglobal=0;
	// creating a thread using thread_function as the start routine
	if(pthread_create(&mythread, NULL, thread_function, NULL)) {
		printf("error creating thread");
		abort();
	}
	// changing the value of muglobal in main()
	for(i=0;i<20;i++) {
		myglobal += 1;
		printf("o");
		// to force writing all user-space buffered data to stdout
		fflush(stdout);
		usleep(SLEEP_DURATION);
	}
	printf("\nmyglobal equals %d\n", myglobal);
	// to block main to support the threads it created unti they terminate
	pthread_exit(NULL);
}
