#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

void *print_message_function(void *ptr) {
	char* message;
	// interpreting as char *
	message = (char *) ptr;
	printf("\n %s \n", message);
	// Terminating the thread
	pthread_exit(NULL);
}

int main() {
	pthread_t thread1, thread2, thread3;
	char *message1 = "Hello";
	char *message2 = "World";
	char *message3 = "!...";
	// Creating 3 threads using print_message_function as the start routine
	// and message1, message2 and message3 as the arguments for the start routine
	
	if(pthread_create(&thread1, NULL, print_message_function, (void*) message1)) {
		fprintf(stderr,"pthread_create failure\n");
		exit(-1);
	}
	if(pthread_create(&thread2, NULL, print_message_function, (void*) message2)) {
		fprintf(stderr,"pthread_create failure\n");
		exit(-1);
	}
	if(pthread_create(&thread3, NULL, print_message_function, (void*) message3)) {
		fprintf(stderr,"pthread_create failure\n");
		exit(-1);
	}
	// to block main to support the threads it created until they terminate
	pthread_exit(NULL);
}
