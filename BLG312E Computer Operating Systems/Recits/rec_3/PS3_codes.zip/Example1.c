#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
int myglobal;
pthread_mutex_t lock;
void* thread_function(void *arg){
	int i,j;
	// changing the value of myglobal in thread_function
	for(i=0;i<20;i++){
		pthread_mutex_lock(&lock); //Entering the critical section
		j=myglobal;
		j=j+1;
		printf(".");
		// to force writing all user-space buffered data to stdout
		fflush(stdout);
		myglobal=j;
		pthread_mutex_unlock(&lock); //Exiting the critical section
		sleep(1);
	}
	pthread_exit(NULL);
}

int main(void){
	pthread_t mythread;
	int i;
	myglobal=0;
	if (pthread_mutex_init(&lock, NULL) != 0)
 	{
		printf("\n mutex init failed\n");
		return 1;
 	}
	// creating a thread using thread_function as the start routine
	if(pthread_create(&mythread,NULL,thread_function,NULL)){
		printf("error creating thread");
		abort();
	}
	// changing the value of myglobal in main()
	for(i=0;i<20;i++){		
		pthread_mutex_lock(&lock); //Entering the critical section
		myglobal = myglobal+1;
		printf("o");
		// to force writing all user-space buffered data to stdout
		fflush(stdout);
		pthread_mutex_unlock(&lock); //Exiting the critical section
		sleep(1);
	}
	pthread_join(mythread, NULL);
 	pthread_mutex_destroy(&lock);
	printf("\nmyglobal equals %d\n",myglobal);
	// to block main to support the threads it created until they terminate
	pthread_exit(NULL);
}
