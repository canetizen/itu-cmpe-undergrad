package Patterns.Singleton;

public class SingletonIdGenerator extends IdGenerator{
    
    private static SingletonIdGenerator instance;
   

    private SingletonIdGenerator(){
        id_counter = 1;
    }

    public static SingletonIdGenerator getInstance(){    
        if(instance == null)
            instance = new SingletonIdGenerator();
        
            return instance;
    }

}
