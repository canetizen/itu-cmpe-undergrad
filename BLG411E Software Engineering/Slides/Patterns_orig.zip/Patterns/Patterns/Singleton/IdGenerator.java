package Patterns.Singleton;


public class IdGenerator {
    protected int id_counter;
    public IdGenerator(){
        id_counter = 1;
    }

    public int get_id(){
        return id_counter++;
    }
}
