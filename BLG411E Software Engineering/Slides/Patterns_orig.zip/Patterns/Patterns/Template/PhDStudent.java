package Patterns.Template;


public class PhDStudent extends Student {
    private int gpa;
    private String thesis_title;

    public PhDStudent(int id, String name, int gpa, String thesis_title){
        super(id, name);
        this.gpa = gpa;
        this.thesis_title = thesis_title;
    }

    public String get_thesis_title(){
        return this.thesis_title;
    }

    public int get_gpa(){
        return this.gpa;
    }


    public void accept(Visitor v){
        v.visit_phd_student(this);
    }
}
