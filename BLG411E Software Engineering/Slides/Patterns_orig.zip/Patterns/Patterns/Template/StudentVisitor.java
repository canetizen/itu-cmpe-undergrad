package Patterns.Template;


public class StudentVisitor extends Visitor {


    public void visit_undergrad_student(UndergradStudent s){
        String str = greet();
        str += ask_gpa(s);
        str += ask_name(s);
        farewell(str);
    }

    public void visit_grad_student(GradStudent s){
        String str = greet();
        str += ask_gpa(s);        
        str += ask_ugpa(s);
        str += ask_name(s);
        farewell(str);
    }

    public void visit_phd_student(PhDStudent s){
        String str = greet();
        str += ask_name(s);
        str += ask_thesis(s);
        farewell(str);
    }
}
