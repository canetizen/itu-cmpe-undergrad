package Patterns.Template;


public abstract class Visitor {

    protected String greet(){
        return "Hello ";
    }

    protected String ask_gpa(Student s){
        if(s.get_gpa() > 80)
            return "honorary ";
        return "";
    }

    protected String ask_ugpa(GradStudent s){
        if(s.get_u_gpa() > 80)
            return "respected ";
        return "";
    }

    protected String ask_name(PhDStudent s){
        return s.get_name();
    }

    protected String ask_name(UndergradStudent s){
        return "student " + s.get_name();
    }

    protected String ask_name(GradStudent s){
        return "fellow " + s.get_name();
    }

    protected String ask_thesis(PhDStudent s){
        return ". How is " + s.get_thesis_title() + " going?";
    }

    protected void farewell(String s){
        System.out.println(s);
    }

    public abstract void visit_undergrad_student(UndergradStudent s);
    public abstract void visit_grad_student(GradStudent s);
    public abstract void visit_phd_student(PhDStudent s);
}
