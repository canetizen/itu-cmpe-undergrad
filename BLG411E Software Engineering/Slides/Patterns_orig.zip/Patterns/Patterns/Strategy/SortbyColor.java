package Patterns.Strategy;

import java.util.Comparator;

public class SortbyColor implements Comparator<Fruit>{
    public int compare(Fruit a, Fruit b)
    {
        int col_a = a.get_color().length();
        int col_b = b.get_color().length();
        
        if(col_a>col_b)
            return 1;
        else if(col_b>col_a)
            return -1;
        else return 0; 
    }
}