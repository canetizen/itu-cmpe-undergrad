package Patterns.Strategy;

import java.util.Comparator;

public class SortbyWeight implements Comparator<Fruit>{
    public int compare(Fruit a, Fruit b)
    {
        if(a.get_weight()>b.get_weight())
            return -1;
        else if(b.get_weight()>a.get_weight())
            return 1;
        else return 0;
    }
}
