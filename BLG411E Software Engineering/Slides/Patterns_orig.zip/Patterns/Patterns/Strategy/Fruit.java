package Patterns.Strategy;

public class Fruit {
    private String name;
    private int weight;
    private Color color;

    public Fruit(String name, int weight, Color color){
        this.name = name;
        this.weight = weight;
        this.color = color;
    }

    public String get_name(){
        return name;
    }

    public int get_weight(){
        return weight;
    }

    public String get_color(){
        return color.toString();
    }

    public String toString(){
        return "{ " + name + ", " + weight + ", " + color + " }";
    }
    
}
