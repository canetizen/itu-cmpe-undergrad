package Patterns.Strategy;

public enum Color{RED, YELLOW, GREEN, BLUE, MAGENTA};
