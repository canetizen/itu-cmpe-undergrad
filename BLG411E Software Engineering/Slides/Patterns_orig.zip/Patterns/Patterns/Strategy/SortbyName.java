package Patterns.Strategy;

import java.util.Comparator;

public class SortbyName implements Comparator<Fruit>{
    public int compare(Fruit a, Fruit b)
    {
        return a.get_name().compareTo(b.get_name());
    }
}
