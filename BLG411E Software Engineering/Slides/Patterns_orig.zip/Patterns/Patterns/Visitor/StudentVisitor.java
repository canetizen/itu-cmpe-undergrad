package Patterns.Visitor;

public class StudentVisitor implements Visitor {
    
    public void visit_undergrad_student(UndergradStudent s){
        String str = "Hello ";
        if(s.get_gpa() > 80)
            str += "honorary ";
        
        str += "student " + s.get_name();
        
        System.out.println(str);
    }

    public void visit_grad_student(GradStudent s){
        String str = "Hello ";
        
        if(s.get_gpa() > 80)
            str += "honorary ";
       
        if(s.get_u_gpa() > 80)
            str += "respected ";
    
        str += "fellow " + s.get_name();
        
        System.out.println(str);
    }

    public void visit_phd_student(PhDStudent s){
        String str = "Hello " + s.get_name() +". How is " + s.get_thesis_title() + "going?";
                
        System.out.println(str);
    }
}
