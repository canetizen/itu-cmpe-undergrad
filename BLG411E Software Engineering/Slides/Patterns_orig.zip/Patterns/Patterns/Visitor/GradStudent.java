package Patterns.Visitor;

public class GradStudent extends Student {
    
    private int u_gpa;
    private int gpa;

    public GradStudent(int id, String name, int u_gpa, int gpa){
        super(id, name);
        this.u_gpa = u_gpa;
        this.gpa = gpa;
    }

    public int get_u_gpa(){
        return this.u_gpa;
    }

    public int get_gpa(){
        return this.gpa;
    }

    public void accept(Visitor v){
        v.visit_grad_student(this);
    }
}
