package Patterns.Visitor;

public class UndergradStudent extends Student {
    
    private int gpa;

    public UndergradStudent(int id, String name, int gpa){
        super(id, name);
        this.gpa = gpa;
    }

    public int get_gpa(){
        return this.gpa;
    }

    public void accept(Visitor v){
        v.visit_undergrad_student(this);
    }
}
