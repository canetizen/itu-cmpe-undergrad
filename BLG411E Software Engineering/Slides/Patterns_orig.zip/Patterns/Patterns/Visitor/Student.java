package Patterns.Visitor;

public abstract class Student {
    protected int id;
    protected String name;
    public Student(int id, String name){
        this.id = id;
        this.name = name;
    }

    public int get_id(){
        return this.id;
    }

    public String get_name(){
        return this.name;
    }
    public abstract void accept(Visitor v);
}
