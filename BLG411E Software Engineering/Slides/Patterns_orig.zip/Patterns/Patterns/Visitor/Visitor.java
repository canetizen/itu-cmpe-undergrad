package Patterns.Visitor;

public interface Visitor {
    public void visit_undergrad_student(UndergradStudent s);
    public void visit_grad_student(GradStudent s);
    public void visit_phd_student(PhDStudent s);
}
