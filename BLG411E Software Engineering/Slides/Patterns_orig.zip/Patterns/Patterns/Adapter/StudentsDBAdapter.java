package Patterns.Adapter;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentsDBAdapter implements StudentAdapter{

    private Connection conn;
    private ResultSet rs;

    public StudentsDBAdapter(){
        try {
            conn = DriverManager.getConnection("jdbc:sqlite:dbs/students.db");
            Statement statement = conn.createStatement();
            statement.setQueryTimeout(30);  // set timeout to 30 sec.    
            rs = statement.executeQuery("select * from Students"); 
            this.next_student();  
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void next_student(){
        try {
            if(rs.next())
                ;
            else conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    public boolean more_students(){
        try {
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public int get_student_number(){
        try {
            return rs.getInt("id");  
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return -1;            

    }
    public String get_student_name(){
        try {
            return rs.getString("name");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return "";
    }
    public int get_student_score(){
        try {
            return rs.getInt("grade");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return -1
        ;
    }
}
