package Patterns.Adapter;

public class Student {
    private int number;
    private String name;
    private int score;

    public Student(int number, String name, int score){
        this.number = number;
        this.name = name;
        this.score = score;
    }

    @Override
    public String toString(){
        return "{"+this.number+", "+this.name+", "+this.score+"}";
    }

    
}
