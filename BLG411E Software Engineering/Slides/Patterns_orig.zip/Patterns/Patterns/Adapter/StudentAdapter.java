package Patterns.Adapter;

public interface StudentAdapter {
    public void next_student();
    public boolean more_students();
    public int get_student_number();
    public String get_student_name();
    public int get_student_score();
}
