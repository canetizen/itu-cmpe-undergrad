package Patterns.Factory;

public class Student {
    private int id;
    private String name;
    private int grade;

    public void set_id(int id){
        this.id = id;
    }

    public void set_name(String name){
        this.name = name;
    }

    public void set_grade(int grade){
        this.grade = grade;
    }

    @Override
    public String toString(){
        return "{"+this.id+", "+this.name+", "+this.grade+"}";
    }

    
}
