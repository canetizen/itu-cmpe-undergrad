package Patterns.Factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentFactory{
    private static Connection conn;
    private static ResultSet rs;

    public static Student get_next_student(){
        try{
            if(conn == null){
                connect();
                Statement statement = conn.createStatement();
                statement.setQueryTimeout(30);  // set timeout to 30 sec.    
                rs = statement.executeQuery("select * from Students");
            }
            if(rs.next())
            {
                Student s = new Student();
                s.set_id(rs.getInt("id"));
                s.set_name(rs.getString("name"));
                s.set_grade(rs.getInt("grade"));
                return s;
            }
            else{
                disconnect();
                return null;
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            disconnect();
            return null;
        }
    }

    private static void connect(){
        try {
            conn = DriverManager.getConnection("jdbc:sqlite:dbs/students.db");   
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void disconnect(){
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
}