package Patterns.Observer;

import java.util.ArrayList;
import java.util.Random;

public class Subject {
    private int some_value;
    private boolean stop;
    private Thread thread;
    private ArrayList<Observer> observers;

    public Subject(){
        some_value = 1;
        stop = false;
        observers = new ArrayList<Observer>();
    }

    public void start(){
        stop = false;
        this.notify_observers();
        Runnable runnable = () -> { 
                                    while(!stop){
                                        try {
                                            Thread.sleep((new Random()).nextInt(300)+200);
                                            some_value++;
                                            this.notify_observers();
                                        } catch (InterruptedException e) {e.printStackTrace();}
                                    } };
        thread = new Thread(runnable);
        thread.start();
                                    
    }

    public void stop(){
        stop = true;
        try {thread.join();} 
        catch (InterruptedException e) {e.printStackTrace();}
        some_value = 1;
    }

    public int get_value(){
        return some_value;
    }

    public void subscribe(Observer o){
        observers.add(o);
    }
    
    public void unsubscribe(Observer o){
        observers.remove(o);
    }

    public void notify_observers(){
        for(Observer o: observers)
            o.notify_observer();
    }

}
