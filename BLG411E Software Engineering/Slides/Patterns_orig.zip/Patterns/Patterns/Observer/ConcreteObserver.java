package Patterns.Observer;

public class ConcreteObserver implements Observer{
    private Subject s;
    
    public ConcreteObserver(Subject s){
        this.s = s;
    }

    public void notify_observer(){
        System.out.println(s.get_value());
    }
}
