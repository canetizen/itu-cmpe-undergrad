package Patterns.Observer;

public class PollingObserver {
    private Subject s;
    public PollingObserver(Subject s){
        this.s = s;
    }

    public void observe(){
        for(int i = 0; i<10; i++){
            System.out.println(s.get_value());
            try {Thread.sleep(100);} 
            catch (InterruptedException e) {e.printStackTrace();}
        }
    }
}
