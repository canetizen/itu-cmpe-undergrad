package Patterns.Observer;

public interface Observer {
    public void notify_observer();
}
