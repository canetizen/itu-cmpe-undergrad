package Patterns.Builder;

public interface StudentBuilder {
    
    public StudentBuilder reset();
    public StudentBuilder set_id(int id);    
    public StudentBuilder set_name(String name);
    public StudentBuilder set_grade(int grade);

}
