package Patterns.Builder;

public class Scholar {
    private int number;
    private String name_surname;
    private int point;

    public Scholar(int number, String name_surname, int point){
        this.number = number;
        this.name_surname = name_surname;
        this.point = point;

    }
    public void set_number(int number){
        this.number = number;
    }

    public void set_name_surname(String name_surname){
        this.name_surname = name_surname;
    }

    public void set_point(int point){
        this.point = point;
    }

    @Override
    public String toString(){
        return "{"+this.number+", "+this.name_surname+", "+this.point+"}";
    }

    
}
