package Patterns.Builder;

public class ScholarBuilder implements StudentBuilder{
    private Scholar instance;

    public ScholarBuilder(){
        instance = new Scholar(-1, "", -1);
    }
    public ScholarBuilder reset(){
        instance = new Scholar(-1, "", -1);
        return this;
    }
    public ScholarBuilder set_id(int id){
        instance.set_number(id);
        return this;
    }   
    public ScholarBuilder set_name(String name){
        instance.set_name_surname(name);
        return this;
    }
    public ScholarBuilder set_grade(int grade){
        instance.set_point(grade);
        return this;
    }

    public Scholar get_result(){
        return instance;
    }
}
