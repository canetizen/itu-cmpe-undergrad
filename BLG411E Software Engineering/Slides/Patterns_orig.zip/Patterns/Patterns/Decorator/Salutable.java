package Patterns.Decorator;

public interface Salutable {
    public String salute();    
    public char get_gender();
    public boolean is_married();
}
