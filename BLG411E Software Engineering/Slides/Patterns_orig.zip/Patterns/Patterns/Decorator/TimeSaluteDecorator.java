package Patterns.Decorator;

import java.util.Calendar;

public class TimeSaluteDecorator extends SaluteDecorator{

    public TimeSaluteDecorator(Salutable s){
        super(s);
    }

    public String salute(){
            Calendar calendar = Calendar.getInstance();
            calendar.getTime();
            int hod = calendar.HOUR_OF_DAY;
            hod = 15;
            if(hod>=6 && hod<12)
                return "Good morning " + wrapped.salute();
            else if(hod>=12 && hod<18)
                return "Good afternoon " + wrapped.salute();
            else if(hod>=18 && hod<24)
                return "Good evening " + wrapped.salute();
            else
                return "Good night " + wrapped.salute();
    }
}
