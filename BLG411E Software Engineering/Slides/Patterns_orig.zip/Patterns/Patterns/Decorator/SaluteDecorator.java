package Patterns.Decorator;

public abstract class SaluteDecorator implements Salutable{
    protected Salutable wrapped;


    public SaluteDecorator(Salutable s){
        this.wrapped = s;
    }

    public char get_gender(){
        return this.wrapped.get_gender();
    }

    public boolean is_married(){
        return this.wrapped.is_married();
    }

}
