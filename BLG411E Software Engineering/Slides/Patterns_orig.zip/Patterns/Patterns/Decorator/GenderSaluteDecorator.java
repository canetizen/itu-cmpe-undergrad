package Patterns.Decorator;

public class GenderSaluteDecorator extends SaluteDecorator {
    
    public GenderSaluteDecorator(Salutable s){
        super(s);
    }

    public String salute(){
        if(this.wrapped.get_gender() == 'M')
            return "Mr."+wrapped.salute();
        else if(this.wrapped.is_married())
            return "Mrs."+wrapped.salute();
        else return "Ms."+wrapped.salute();
    }
}
