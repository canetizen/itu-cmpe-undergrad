package Patterns.Decorator;

public class Person implements Salutable {
    private char gender;
    private boolean married;
    private String name;
    private String surname;

    public Person(String name, String surname, char gender, boolean married){
        this.name = name;
        this.surname = surname;
        this.gender = gender;
        this.married = married;
    } 

    public char get_gender(){
        return gender;
    }

    public boolean is_married(){
        return married;
    }

    public String salute(){
        return surname;
    }
}
