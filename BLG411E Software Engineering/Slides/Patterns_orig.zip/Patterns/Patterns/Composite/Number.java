package Patterns.Composite;

public class Number extends Expression {
    public Number(String exp_str){
        this.exp_str = exp_str;
        for(int i=0;i<exp_str.length();i++)
            if(!Character.isDigit(exp_str.charAt(0))){
                this.exp_str = "0";
                break;
            }
    }
}
