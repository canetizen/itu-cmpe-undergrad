package Patterns.Composite;

public class Expression{
    protected String exp_str;
    public void eval(){
        System.out.println(this.exp_str);
    }
    public String toString(){
        return exp_str;
    }
}
