package Patterns.Composite;

public class CompositeExpression extends Expression {
    public CompositeExpression(Expression a, Expression b, String op){
        op = ""+op.charAt(0);
        if(!(op.equals("+") || op.equals("-") || op.equals("*") || op.equals("/")))
            op = "+";
        
        this.exp_str = "( " + a + " "+ op + " " + b + " )";
    }
}
