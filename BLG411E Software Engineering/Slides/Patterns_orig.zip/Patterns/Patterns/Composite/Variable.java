package Patterns.Composite;

public class Variable extends Expression{
        
    public Variable(String exp_str){
        this.exp_str = exp_str;
        for(int i=0;i<exp_str.length();i++)
            if(!Character.isAlphabetic(exp_str.charAt(i)) || Character.isUpperCase(exp_str.charAt(i))){
                this.exp_str = "x";
                break;
            }
        
    }
}
