//import Patterns.Singleton.*;
//import Patterns.Factory.*;
//import Patterns.Builder.*;
//import Patterns.Adapter.*;
//import Patterns.Composite.*;
//import Patterns.Decorator.*;
//import Patterns.Strategy.*;
import Patterns.Observer.*;
//import Patterns.Visitor.*;
//import Patterns.Template.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.TreeSet;

class Main{
    public static void main(String[] args){
        //Main.singleton_example();
        //Main.factory_example();
        //Main.builder_example();
        //Main.adapter_example();
        //Main.composite_example();
        //Main.decorator_example();
        //Main.strategy_example();
        //Main.iterator_example();
        Main.observer_example();
        //Main.visitor_example();
        //Main.template_method_example();
    }
 /* 
    public static void singleton_example(){
        IdGenerator id_gen = new IdGenerator();
        for(int i=0;i<5;i++)
            System.out.print(id_gen.get_id()+"-");
        System.out.println();

         
        IdGenerator id_gen_2 = new IdGenerator();
        System.out.println(id_gen_2.get_id());
        
        SingletonIdGenerator id_gen_3 = SingletonIdGenerator.getInstance();   
        System.out.println(id_gen_3.get_id());
    }
*/
  /*  
    public static void factory_example(){
        while(true){
            Student s = StudentFactory.get_next_student();
            if(s == null)
                break;
            System.out.println(s);
        }
    }
*/

/* 
    public static void builder_example(){
        ScholarBuilder sb = new ScholarBuilder();

        Scholar s = sb.set_grade(90).set_name("Tolga").get_result();
        System.out.println(s);
    }

*/
/* 
    public static void adapter_example(){
        StudentAdapter sa = new StudentsDBAdapter();
        //StudentAdapter sa = new ScholarsDBAdapter();

        while(sa.more_students()){
            Student s = new Student(sa.get_student_number(), 
                                    sa.get_student_name(),
                                    sa.get_student_score());
            System.out.println(s);
            sa.next_student();
        }
    }
*/

/* 
    public static void composite_example(){
        Expression a = new Patterns.Composite.Number("4");
        Expression b = new Variable("a");
        Expression c = new CompositeExpression(a, b, "*");

        c.eval();

        Expression d = new Variable("d");
        Expression e = new CompositeExpression(c, d, "-");

        e.eval();

        Expression f = new CompositeExpression(e, c, "/");
        f.eval();
    }
*/

/*
    public static void decorator_example(){
        Person p = new Person("Tolga", "Ovatman", 'M', false);

        Salutable s = new GenderSaluteDecorator(new TimeSaluteDecorator(p));
        System.out.println(s.salute());
    }
*/
 /* 
    public static void strategy_example(){
        ArrayList<Fruit> a_list = new ArrayList<Fruit>();
        a_list.add(new Fruit("apple", 100, Color.RED));
        a_list.add(new Fruit("banana", 80, Color.YELLOW));
        a_list.add(new Fruit("berry", 20, Color.BLUE));
        a_list.add(new Fruit("cucumber", 90, Color.GREEN));
        a_list.add(new Fruit("dragon", 120, Color.MAGENTA));

        a_list.sort(new SortbyWeight());
        for(Fruit a_f: a_list)
            System.out.println(a_f);
    }
    */
/* 
    public static void iterator_example(){
        Collection<String> c;
        //c = new ArrayList<String>();
        //c = new LinkedList<String>();
        //c = new PriorityQueue<String>();
        //c = new TreeSet<String>();

        dummy_fill(c);
        print_all(c.iterator());
    }

    public static void dummy_fill(Collection<String> c){
        for(int i=0;i<10;i++)
            c.add(""+i);
    }

    public static void print_all(Iterator<String> i){
        while(i.hasNext())
            System.out.print(i.next()+" ");
        System.out.println();
    }
    */

    public static void observer_example(){
        Subject s = new Subject();
        /* 
        PollingObserver po = new PollingObserver(s);
        s.start();
        po.observe();
        s.stop();
        */

        ConcreteObserver co = new ConcreteObserver(s);
        s.subscribe(co);

        s.start();
        try {Thread.sleep(10000);} 
        catch (InterruptedException e) {e.printStackTrace();}
        s.stop();
        
    }

/* 
    public static void visitor_example(){
        ArrayList<Student> students = new ArrayList<Student>();
        students.add(new UndergradStudent(1, "Tolga", 90));
        students.add(new GradStudent(2, "Duygu", 85, 90));
        students.add(new PhDStudent(3, "Teoman", 92, "Some Thesis"));

        Visitor v = new StudentVisitor();

        for(Student s: students)
            s.accept(v);
    }
*/
/* 
    public static void template_method_example(){
        ArrayList<Student> students = new ArrayList<Student>();
        students.add(new UndergradStudent(1, "Tolga", 90));
        students.add(new GradStudent(2, "Duygu", 85, 90));
        students.add(new PhDStudent(3, "Teoman", 92, "Some Thesis"));

        Visitor v = new StudentVisitor();

        for(Student s: students)
            s.accept(v);
    }
    */
}