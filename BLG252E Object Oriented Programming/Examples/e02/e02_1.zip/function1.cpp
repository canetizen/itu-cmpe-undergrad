// function1.cpp
// contains decleration of function1

#include <iostream>					// Standard header file for input and output

// function1 increments the input parameter by one
double function1(double input) {
	std::cout << "Function 1 is running \n";
	return input + 1;
}