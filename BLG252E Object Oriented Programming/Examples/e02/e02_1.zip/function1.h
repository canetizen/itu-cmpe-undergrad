// function1.h
// Header file of the function1
// function1 increments the input parameter by one
double function1(double);