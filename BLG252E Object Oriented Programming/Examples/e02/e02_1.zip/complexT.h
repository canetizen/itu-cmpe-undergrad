// complexh.cpp
// contains decleration of ComplexT
// ComplexT is used to define complex numbers
struct ComplexT {      	// Declaration (type) of complex numbers
	double re, im;		// real and imaginary parts
};
